const search = document.getElementById("search");
const cards = document.querySelectorAll(".card");

search.addEventListener("keyup", function () {

    const value = search.value.toLowerCase();

    cards.forEach(function(card){

        const title = card.querySelector("h3").textContent.toLowerCase();

        if(title.includes(value)){
            card.style.display = "block";
        }else{
            card.style.display = "none";
        }

    });

});

// Welcome Message
window.onload = function(){
    alert("🎬 Welcome to Movie Addict!");
};

// Movie Click
cards.forEach(function(card){

    card.addEventListener("click", function(){

        const movie = card.querySelector("h3").textContent;

        alert("Now Showing: " + movie);

    });

});